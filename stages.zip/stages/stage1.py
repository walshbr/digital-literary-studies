# given a file path, store and print it

text_path = 'repos/books/a001/a001.tei.xml'

print(text_path)
